package com.crossover.techtrial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author crossover
 */
@SpringBootApplication
public class CrossLibraryApplication {
    public static void main(String[] args) {
        SpringApplication.run(CrossLibraryApplication.class, args);
    }
}
